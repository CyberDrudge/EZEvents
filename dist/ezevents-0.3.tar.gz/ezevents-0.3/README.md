
                          EZEvents

                         View your upcoming events and add events to your Google Calendar


    ~ What do I need?
      
      Python 2.6+
      pip
      A Google account 

    ~ Usage
      
      Run the command like so:
      
        ezevents [options] 
      
      You will be prompted for your Google Calendar email and password the
      first time, which will be stored safely.
      
      Once logged in, events from all your calendars should be displayed
      on running the command.
